<!DOCTYPE html>
<html>
<head>
	<title>...</title>
</head>
<body>
<script>
	// Create a media condition that targets viewports at least 768px wide
const mediaQuery = window.matchMedia('(min-width: 1170px)')
// Check if the media query is true
if (mediaQuery.matches) {
  	window.location.replace("./Authentication")

}
else{
 window.location.replace("./Mobile")
}


	
</script>
</body>
</html>
